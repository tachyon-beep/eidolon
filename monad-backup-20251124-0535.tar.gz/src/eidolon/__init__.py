"""
Eidolon hierarchical agent system package.
"""
